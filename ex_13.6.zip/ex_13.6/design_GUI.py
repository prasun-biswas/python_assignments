# TIE-02106 Programming 1: introduction
# Mahabub Hasan(281749)
# Prasun Biswas(267948)
# Solution of task 13.6: Food Order System:GUI Project (group work):

'''
This program is a food billing interface. The program reads the food items from a file name as 'foodfile.txt'.
The program creates food buttons corresponding to the food names available in the 'foodfile.txt'.
When the order is taken using the food buttons, the program shows the order in the textbox.
The program calculates the total price of the food order when the done button is pressed.
Cancel button cancels the whole order and allows the order to be taken again from the begining.
Quit button stops the program.

We beleive the program is a scaleable user interface. 
'''

from tkinter import *


class display():

    '''
    Constructor takes the fooddict as a parameter. The fooddict key is
    string and fooddict value is float.
    '''

    def __init__(self, fooddict):
        controlframe = Tk()
        self.__controlframe = controlframe
        self.__controlframe.title("Food Order System")
        self.__fooddict = fooddict
        self.__namelist = []  # Initializing a data structure for the food names
        self.__print_fooddict = {}  # Initializing the data structure for the ordered food
        self.__accumulate = 0
        for key, value in self.__fooddict.items():
            self.__namelist.append(key)

    '''The callback method takes the index as parameter, finds the food_name 
    from the namelist, with the food_name, finds the price of the food,
    from the food_dict, accumulates the total price and updates the print
    _fooddict'''

    def callback(self, index):
        food_name = self.__namelist[index]  # Extracting the food name from namelist
        price = self.__fooddict[food_name]  # Extracting the value of the food obtained from the fooddict
        price = float("{0:.2f}".format(price))
        self.__accumulate = price + self.__accumulate  # Accumulating the total price
        self.update_final_dict(food_name, price)  # Calling the method update_final_dict with parameters keys and values
        self.__text.insert("1.0", '1 {} added'.format(food_name) + '\n')


    '''
    The method updates the final dict for printing purpose, it takes the 
    parameters key and value it check if the key is already inside the print_
    fooddict else it accumulates the value for multiple orders of the same food
    '''

    def update_final_dict(self, food_name, price):
        if food_name not in self.__print_fooddict.keys():
            self.__print_fooddict[food_name] = price
        else:
            price = self.__print_fooddict[food_name] + price
            price = float("{0:.2f}".format(price))
            self.__print_fooddict[food_name] = price

    def done(self):
        temp_list = []  # Initializing a temporary list as temp_list
        for food_name, price in self.__print_fooddict.items():
            quantity = self.find_quantity(food_name,price)  # calling the method find_quantity to calculate the total order quantity with parameters key and value
            s = str(quantity) + "*" + str(food_name) + "-" + str(price)
            temp_list.append(s)
        self.__text.insert(END, '----------------------------' + '\n')
        for items in temp_list:
            self.__text.insert(END, items + '\n') # Prints the order in textbox

        self.__accumulate = float("{0:.2f}".format(self.__accumulate))
        self.__text.insert(END, '----------------------------' + '\n')
        self.__text.insert(END, 'Total Amount -{}'.format(self.__accumulate))  # Prints the total amount in textbox
        self.__Done_button.configure(state=DISABLED)

    '''The method takes key and value as parameter, extracts unit value from 
    food dict with the key and finds the quantity and returns it'''

    def find_quantity(self, food_name, price):
        unitprice = self.__fooddict[food_name]
        quantity = float(price) // float(unitprice)
        return quantity

    '''This method cancels the whole order and starts from the begining'''

    def cancel(self):
        self.__text.delete("1.0", END)
        self.__print_fooddict = {}
        self.__accumulate = 0
        self.__Done_button.configure(state=NORMAL)

    '''This method quits the program'''

    def quit(self):
        self.__controlframe.destroy()

    '''This method creates the window/frame, creates butting 
    and labels and textbox'''

    def showlist(self):
        self.__frame = Frame(self.__controlframe, height=1)  # Initializing the frame
        self.__frame.pack()
        label = Label(self.__frame,
                      text="Click the food name, Click multiple times for multiple items")  # Setting up a label
        label.grid(row=0, column=0)
        self.__text = Text(self.__frame, height=25, width=35)  # Setting up a text box to show a result
        self.__text.grid(row=2, column=5, padx=20, pady=5)
        row = 3
        column = 1

        '''Creating buttons for each of the food item in the food file'''
        for index, x in enumerate(self.__namelist):
            foodButton = Button(self.__frame, text=x, command=lambda index=index: self.callback(index), height=2,
                                width=20)  # Calls the callback function with index as parameter
            foodButton.grid(row=row, column=column)
            row = row + 1
            if row == 6:
                column += 1
                row = 3

        '''Creating buttons for done cancel and quit'''
        self.__Done_button = Button(self.__frame, text="Done", command=self.done, height=2,
                                    width=20)                                               # call done method
        self.__Done_button.grid(row=2, column=1)
        self.__cancel_button = Button(self.__frame, text="Cancel", command=self.cancel, height=2,
                                      width=20)                                             # call cancel method
        self.__cancel_button.grid(row=2, column=2)
        self.__quit_button = Button(self.__frame, text="Quit", command=self.quit, height=2,
                                    width=20)                                               # call quit method
        self.__quit_button.grid(row=2, column=3)

        self.__controlframe.mainloop()


def main():
    fooddict = {}                           # Initializing the dict
    file_name = open("foodfile.txt", "r")  # Opening the file in read mode
    for line in file_name:
        lines = line.rstrip()
        lines = lines.split("-")
        foodname = lines[0]
        price = lines[1]
        fooddict[foodname] = float(price)  # Saving the name of the food as key and price as value in the dict
    food_obj = display(fooddict)
    food_obj.showlist()                     # Calling the function showlist with object


main()
